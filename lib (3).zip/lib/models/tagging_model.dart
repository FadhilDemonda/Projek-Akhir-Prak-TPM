class TaggingModel {}
